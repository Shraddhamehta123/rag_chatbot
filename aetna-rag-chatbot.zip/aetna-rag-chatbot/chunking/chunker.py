"""
chunking/chunker.py
=====================
STEP 3 of the architecture: Chunk Documents.

WHY RecursiveCharacterTextSplitter, AND WHY 1000 / 200
--------------------------------------------------------
LangChain's `RecursiveCharacterTextSplitter` tries to split on paragraph
breaks first, then sentences, then words -- only falling back to a hard
character cut as a last resort. That matters a lot for insurance
documents: EOC/SBC text is organized into numbered benefit clauses
("Inpatient hospital care... Deductible: $... Coinsurance: ..."), and a
naive fixed-length splitter will happily cut a clause in half, separating
a benefit name from its dollar amount -- which is exactly the kind of
error that produces a wrong, confidently-stated answer to a member.

- **Chunk size = 1000 characters** (~200-250 tokens): large enough to hold
  a full benefit clause or a Q&A pair from the SBC without truncation,
  small enough that retrieval stays precise (a 4000-char chunk buries the
  answer in irrelevant neighboring clauses and dilutes embedding
  similarity).
- **Chunk overlap = 200 characters**: guards against the case where the
  actual answer sits right at a chunk boundary (e.g. "prior authorization
  is required for..." ends one chunk and the condition list starts the
  next). The 200-char overlap means that boundary content appears whole
  in at least one chunk.

These are sane defaults for regulatory/benefits prose; they're exposed as
config (`Settings.chunk_size` / `chunk_overlap`) so they can be tuned per
document type without a code change.

METADATA
---------
Every chunk carries `file_name`, `page_number`, and `document_type` so
that:
1. The Streamlit UI can show "Source: Aetna_EOC_2026.pdf, page 42".
2. Retrieval can be filtered ("only search the SBC" for a benefits-summary
   question) without a separate index per document type.
3. The Delta table schema below has a natural primary key
   (file_name + page_number + chunk_index).
"""

from dataclasses import dataclass, field
from typing import Dict, List

from langchain.text_splitter import RecursiveCharacterTextSplitter

from config.settings import settings
from ingestion.pdf_loader import PageDocument
from utils.logging_utils import get_logger

logger = get_logger(__name__)


@dataclass
class Chunk:
    """A single retrievable unit of text plus its provenance metadata."""

    chunk_id: str
    text: str
    file_name: str
    document_type: str
    page_number: int
    chunk_index_on_page: int
    metadata: Dict = field(default_factory=dict)


def _make_chunk_id(file_name: str, page_number: int, chunk_index_on_page: int) -> str:
    """
    Deterministic ID so re-running ingestion on the same PDF produces the
    same chunk_ids -- this makes the Delta MERGE (upsert) in
    `delta_table_manager.py` idempotent instead of creating duplicates
    every time a document is re-ingested.
    """
    safe_name = file_name.replace(" ", "_").replace(".", "_")
    return f"{safe_name}__p{page_number}__c{chunk_index_on_page}"


def chunk_pages(
    pages: List[PageDocument],
    chunk_size: int = None,
    chunk_overlap: int = None,
) -> List[Chunk]:
    """
    Split a list of extracted pages into overlapping text chunks.

    Parameters
    ----------
    pages : List[PageDocument]
        Output of `ingestion.pdf_loader.load_pdf(s)`.
    chunk_size, chunk_overlap : Optional[int]
        Override the configured defaults (1000 / 200). Left as parameters
        (rather than hardcoded) so tests and experiments (e.g. an MLflow
        sweep comparing chunk sizes) don't need to monkeypatch config.

    Returns
    -------
    List[Chunk]
        Flattened list across all input pages, ready for embedding.
    """
    chunk_size = chunk_size or settings.chunk_size
    chunk_overlap = chunk_overlap or settings.chunk_overlap

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        # Priority order: paragraph -> line -> sentence -> word -> char.
        # This is what makes the splitter "recursive" -- it only drops to
        # the next, more destructive separator if the text doesn't fit.
        separators=["\n\n", "\n", ". ", " ", ""],
        length_function=len,
    )

    all_chunks: List[Chunk] = []

    for page in pages:
        try:
            raw_chunks = splitter.split_text(page.text)
        except Exception as exc:
            logger.error(
                "Chunking failed for %s page %d: %s. Skipping page.",
                page.file_name,
                page.page_number,
                exc,
            )
            continue

        for idx, raw_text in enumerate(raw_chunks):
            chunk = Chunk(
                chunk_id=_make_chunk_id(page.file_name, page.page_number, idx),
                text=raw_text,
                file_name=page.file_name,
                document_type=page.document_type,
                page_number=page.page_number,
                chunk_index_on_page=idx,
                metadata={
                    "file_name": page.file_name,
                    "document_type": page.document_type,
                    "page_number": page.page_number,
                },
            )
            all_chunks.append(chunk)

    logger.info(
        "Chunked %d pages into %d chunks (chunk_size=%d, overlap=%d).",
        len(pages),
        len(all_chunks),
        chunk_size,
        chunk_overlap,
    )
    return all_chunks
