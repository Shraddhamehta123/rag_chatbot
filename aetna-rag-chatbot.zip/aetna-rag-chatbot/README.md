# Aetna Virtual Assistant — RAG Chatbot on Azure Databricks

A production-grade Retrieval Augmented Generation (RAG) chatbot that answers
member, provider, and policy questions from Aetna Medicare source documents
(Evidence of Coverage, Summary of Benefits and Coverage, Medicare Managed
Care Manual).

> **Note on scope**: This is a reference implementation / architecture
> starter kit. It uses "Aetna" only as an illustrative Medicare-plan use
> case — swap in your own organization's documents and secret scopes before
> using it against real member data. Nothing here calls any real Aetna
> system; it is a generic insurance-document RAG pattern.

---

## 1. High-Level Architecture (ASCII)

```
                                   ┌─────────────────────────────┐
                                   │        Streamlit UI         │
                                   │  (frontend/app.py)          │
                                   │  chat + citations + debug   │
                                   └──────────────┬───────────────┘
                                                  │ user question
                                                  ▼
                                   ┌─────────────────────────────┐
                                   │        RAGPipeline          │
                                   │  (rag_pipeline/rag_pipeline)│
                                   │  retrieve→build_context→gen │
                                   └──────┬───────────────┬──────┘
                                          │               │
                         retrieve()      │               │ generate_answer()
                                          ▼               ▼
                     ┌───────────────────────────┐   ┌────────────────────┐
                     │  RetrievalService          │   │  Azure OpenAI       │
                     │  (rag_pipeline/retrieval)  │   │  GPT-4o (chat)      │
                     │  hybrid + rerank optional  │   └────────────────────┘
                     └──────────────┬─────────────┘
                                    │ similarity_search()
                                    ▼
                     ┌───────────────────────────┐
                     │  Databricks Vector Search  │
                     │  Index (vector_search/)    │
                     └──────────────┬─────────────┘
                                    │ synced from
                                    ▼
                     ┌───────────────────────────┐
                     │  Delta Table               │
                     │  chunk_id | text | embed…  │
                     │  (Unity Catalog)            │
                     └──────────────┬─────────────┘
                                    ▲ insert
                                    │
   ┌─────────────┐   ┌─────────────┴─────┐   ┌──────────────────┐   ┌────────────────────┐
   │ PDF Sources  │──▶│ Ingestion         │──▶│ Chunking          │──▶│ Embeddings          │
   │ EOC/SBC/MMCM │   │ (PyMuPDF loader)  │   │ (RecursiveChar…)  │   │ text-embedding-3-lg │
   └─────────────┘   └───────────────────┘   └───────────────────┘   └────────────────────┘

   Cross-cutting: MLflow tracing • Structured logging • Databricks Secret Scope • pytest
```

## 2. Solution Overview

| Stage | Component | Purpose |
|---|---|---|
| Ingest | `ingestion/pdf_loader.py` | Reads EOC/SBC/MMCM PDFs with PyMuPDF, handles large files page-by-page, logs and recovers from per-page errors |
| Chunk | `chunking/chunker.py` | Splits page text into 1000-char chunks / 200-char overlap, attaches `file_name`, `page_number`, `document_type` metadata |
| Embed | `embeddings/embedding_service.py` | Calls Azure OpenAI `text-embedding-3-large` in batches, with retry/backoff |
| Store | `vector_search/delta_table_manager.py` | Creates/upserts the Unity Catalog Delta table that is the system of record for chunks + vectors |
| Index | `vector_search/vector_index_manager.py` | Creates the Databricks Vector Search endpoint + index, syncs from the Delta table |
| Retrieve | `rag_pipeline/retrieval_service.py` | Top-K similarity search (+ optional keyword hybrid + rerank), configurable K/threshold |
| Generate | `rag_pipeline/rag_pipeline.py` | Grounds GPT-4o strictly in retrieved context, refuses to hallucinate, cites sources |
| Serve | `frontend/app.py` | Streamlit chat UI with history, citations, confidence, debug sidebar |
| Observe | `utils/mlflow_tracking.py` | MLflow traces, token usage, latency per request |
| Secure | `config/settings.py` | All secrets pulled from Databricks Secret Scope — nothing hardcoded |

## 3. Folder Structure

```
aetna-rag-chatbot/
├── data/                       # local sample PDFs / scratch (gitignored in real repo)
├── notebooks/
│   └── 00_setup_and_deploy.py  # Databricks notebook: cluster + pipeline orchestration
├── ingestion/
│   └── pdf_loader.py
├── chunking/
│   └── chunker.py
├── embeddings/
│   └── embedding_service.py
├── vector_search/
│   ├── delta_table_manager.py
│   └── vector_index_manager.py
├── rag_pipeline/
│   ├── prompt_templates.py
│   ├── retrieval_service.py
│   ├── rag_pipeline.py
│   ├── memory.py               # Enhancement 1: conversational memory
│   ├── query_rewriter.py       # Enhancement 3: query rewriting
│   ├── reranker.py             # Enhancement 4: reranking
│   └── guardrails.py           # Enhancement 6: guardrails
├── frontend/
│   └── app.py
├── config/
│   └── settings.py
├── utils/
│   ├── logging_utils.py
│   ├── mlflow_tracking.py
│   └── feedback_logger.py      # Enhancement 5: feedback logging
├── tests/
│   ├── test_ingestion.py
│   ├── test_chunking.py
│   ├── test_retrieval.py
│   └── test_rag_pipeline.py
├── requirements.txt
└── README.md
```

## 4. Deployment (see full steps in `notebooks/00_setup_and_deploy.py`)

1. Import this repo as a Databricks Repo (Git folder).
2. Create/attach a cluster (see cluster spec in the notebook header).
3. Run `%pip install -r requirements.txt` on the cluster.
4. Create the Secret Scope: `databricks secrets create-scope aetna-rag`, then add
   `azure-openai-key`, `azure-openai-endpoint`, `databricks-token`, `vector-search-endpoint`.
5. Run `notebooks/00_setup_and_deploy.py` end-to-end (ingest → chunk → embed → load → index).
6. Deploy `frontend/app.py` via Databricks Apps (`databricks apps deploy`) or run
   `streamlit run frontend/app.py` from a driver node / local machine pointed at the
   same Unity Catalog workspace.

## 5. Future Improvements

- Swap keyword hybrid search for a native Databricks BM25 index once GA.
- Add PII redaction pass before chunks are persisted (member-identifying data).
- Multi-turn slot-filling for plan-year/plan-ID disambiguation.
- A/B test reranker models via MLflow Model Registry.
- Nightly Delta Live Tables job to pick up updated CMS/EOC documents automatically.
