# Databricks notebook source
# MAGIC %md
# MAGIC # Aetna Virtual Assistant — Setup & Deployment Notebook
# MAGIC
# MAGIC Run this notebook top-to-bottom to stand up the full pipeline:
# MAGIC ingest PDFs -> chunk -> embed -> load to Delta -> build/sync Vector Search index.
# MAGIC
# MAGIC ## Recommended cluster configuration
# MAGIC | Setting | Value |
# MAGIC |---|---|
# MAGIC | Databricks Runtime | 15.4 LTS (ML) |
# MAGIC | Node type | Standard_DS4_v2 (or equivalent, 4 cores / 28 GB) |
# MAGIC | Workers | 2-4 (autoscaling) — embedding is I/O bound, not compute-heavy |
# MAGIC | Access mode | Shared (Unity Catalog) |
# MAGIC | Photon | Enabled |
# MAGIC
# MAGIC ## Secret scope required before running
# MAGIC ```bash
# MAGIC databricks secrets create-scope aetna-rag
# MAGIC databricks secrets put-secret aetna-rag azure-openai-key
# MAGIC databricks secrets put-secret aetna-rag azure-openai-endpoint
# MAGIC databricks secrets put-secret aetna-rag databricks-host
# MAGIC databricks secrets put-secret aetna-rag databricks-token
# MAGIC ```

# COMMAND ----------

# MAGIC %pip install -r ../requirements.txt
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import sys
from pathlib import Path

sys.path.append(str(Path.cwd().parent))

from ingestion.pdf_loader import load_pdfs
from chunking.chunker import chunk_pages
from embeddings.embedding_service import generate_embeddings
from vector_search.delta_table_manager import create_table_if_not_exists, upsert_chunks
from vector_search.vector_index_manager import setup_vector_search, sync_index_if_needed
from config.settings import settings

settings.validate()
print("Configuration validated. Target Delta table:", settings.full_delta_table_path)

# COMMAND ----------

# MAGIC %md ## Step 1-2: Load & Parse PDFs
# MAGIC Point this at your Unity Catalog Volume (or DBFS path) holding the
# MAGIC source documents. Example Volume path:
# MAGIC `/Volumes/aetna_rag_catalog/virtual_assistant/source_documents/`

# COMMAND ----------

SOURCE_DOCUMENT_PATHS = [
    "/Volumes/aetna_rag_catalog/virtual_assistant/source_documents/Aetna_EOC_2026.pdf",
    "/Volumes/aetna_rag_catalog/virtual_assistant/source_documents/Aetna_SBC_2026.pdf",
    "/Volumes/aetna_rag_catalog/virtual_assistant/source_documents/Medicare_Managed_Care_Manual.pdf",
]

pages = load_pdfs(SOURCE_DOCUMENT_PATHS)
print(f"Loaded {len(pages)} pages across {len(SOURCE_DOCUMENT_PATHS)} documents.")

# COMMAND ----------

# MAGIC %md ## Step 3: Chunk Documents

# COMMAND ----------

chunks = chunk_pages(pages)
print(f"Produced {len(chunks)} chunks.")

# COMMAND ----------

# MAGIC %md ## Step 4: Generate Embeddings

# COMMAND ----------

chunk_texts = [c.text for c in chunks]
embeddings = generate_embeddings(chunk_texts)
assert len(embeddings) == len(chunks)

# COMMAND ----------

# MAGIC %md ## Step 5: Store Embeddings in Delta Table

# COMMAND ----------

create_table_if_not_exists()
num_written = upsert_chunks(chunks, embeddings)
print(f"Upserted {num_written} chunks into {settings.full_delta_table_path}.")

# COMMAND ----------

# MAGIC %md ## Step 6: Create/Sync Databricks Vector Search Index

# COMMAND ----------

setup_vector_search()
sync_index_if_needed()

# COMMAND ----------

# MAGIC %md ## Smoke test: run one question through the full pipeline

# COMMAND ----------

from rag_pipeline.rag_pipeline import RAGPipeline

pipeline = RAGPipeline()
response = pipeline.answer_question("What is my annual deductible for inpatient hospital care?")
print("ANSWER:\n", response.answer)
print("\nCONFIDENCE:", response.confidence)
print("\nSOURCES:")
for s in response.sources:
    print(f"  - {s.file_name} p.{s.page_number} (score={s.score:.2f})")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 10: Deploy the Streamlit frontend
# MAGIC
# MAGIC **Option A — Databricks Apps (recommended for production):**
# MAGIC ```bash
# MAGIC databricks apps create aetna-virtual-assistant
# MAGIC databricks apps deploy aetna-virtual-assistant --source-code-path ./frontend
# MAGIC ```
# MAGIC
# MAGIC **Option B — Local / VM for testing:**
# MAGIC ```bash
# MAGIC streamlit run frontend/app.py
# MAGIC ```
# MAGIC
# MAGIC ## Production deployment recommendations
# MAGIC 1. Put the Streamlit app behind SSO (Databricks Apps handles this natively).
# MAGIC 2. Schedule this notebook as a Databricks Job (weekly or on document
# MAGIC    upload trigger) so plan-year updates flow through automatically.
# MAGIC 3. Set `pipeline_type="CONTINUOUS"` on the Vector Search index only if
# MAGIC    document updates become frequent enough to justify the extra cost.
# MAGIC 4. Enable Unity Catalog audit logging on the Delta table and the
# MAGIC    `chat_feedback` table for compliance review.
# MAGIC 5. Add a rate limiter / Azure API Management layer in front of the
# MAGIC    Azure OpenAI resource to control cost under high chat volume.
