"""
Root conftest.py — ensures the project root is on sys.path so tests can
do `from config.settings import settings` etc. without installing the
package, and provides safe dummy env vars so `Settings()` construction
never fails during collection.
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

os.environ.setdefault("AZURE_OPENAI_ENDPOINT", "https://fake.openai.azure.com")
os.environ.setdefault("AZURE_OPENAI_KEY", "fake-key-for-tests")
os.environ.setdefault("DATABRICKS_HOST", "https://fake.databricks.com")
os.environ.setdefault("DATABRICKS_TOKEN", "fake-token-for-tests")
