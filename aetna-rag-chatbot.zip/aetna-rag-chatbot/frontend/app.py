"""
frontend/app.py
=================
STEP 10 of the architecture: Display in Streamlit.

Run locally with:
    streamlit run frontend/app.py

Or deploy via Databricks Apps:
    databricks apps deploy aetna-virtual-assistant --source-code-path frontend/
"""

import sys
from pathlib import Path

import streamlit as st

# Make the project root importable when Streamlit runs this file directly.
sys.path.append(str(Path(__file__).resolve().parent.parent))

from rag_pipeline.memory import ConversationMemory  # noqa: E402
from rag_pipeline.rag_pipeline import RAGPipeline  # noqa: E402
from utils.feedback_logger import FeedbackEvent, log_feedback  # noqa: E402
from utils.logging_utils import set_debug_mode  # noqa: E402

st.set_page_config(
    page_title="Aetna Virtual Assistant",
    page_icon="💬",
    layout="wide",
)


# ----------------------------------------------------------------------
# Session state initialization
# ----------------------------------------------------------------------
if "memory" not in st.session_state:
    st.session_state.memory = ConversationMemory(max_turns=5)

if "chat_log" not in st.session_state:
    # Separate from `memory` (which only holds text for the LLM prompt) --
    # `chat_log` also stores sources/confidence for rendering.
    st.session_state.chat_log = []  # list of dicts: role, content, sources, confidence

if "pipeline" not in st.session_state:
    st.session_state.pipeline = None  # built lazily once sidebar settings are read


# ----------------------------------------------------------------------
# Sidebar: model info, retrieval settings, debug mode
# ----------------------------------------------------------------------
with st.sidebar:
    st.title("⚙️ Settings")

    st.subheader("Model Info")
    st.markdown(
        """
        - **LLM**: Azure OpenAI GPT-4o
        - **Embedding model**: text-embedding-3-large
        - **Vector store**: Databricks Vector Search
        """
    )

    st.subheader("Retrieval")
    top_k = st.slider("Retrieved document count (Top K)", min_value=1, max_value=10, value=5)
    score_threshold = st.slider(
        "Minimum similarity score", min_value=0.0, max_value=1.0, value=0.70, step=0.05
    )
    enable_hybrid = st.checkbox("Enable hybrid (keyword + vector) search", value=True)
    enable_reranking = st.checkbox("Enable reranking", value=True)
    enable_query_rewriting = st.checkbox("Enable follow-up query rewriting", value=True)

    st.subheader("Debug")
    debug_mode = st.checkbox("Debug mode (verbose logs)", value=False)
    set_debug_mode(debug_mode)

    if st.button("🗑️ Clear chat"):
        st.session_state.memory.clear()
        st.session_state.chat_log = []
        st.rerun()

    st.caption(
        "This assistant answers only from Aetna plan documents (EOC, SBC, "
        "Medicare Managed Care Manual). It does not give medical advice."
    )


# Rebuild the pipeline whenever sidebar settings change, reusing the same
# ConversationMemory instance so history survives a settings tweak.
st.session_state.pipeline = RAGPipeline(
    top_k=top_k,
    score_threshold=score_threshold,
    enable_hybrid_search=enable_hybrid,
    enable_reranking=enable_reranking,
    enable_query_rewriting=enable_query_rewriting,
    memory=st.session_state.memory,
)


# ----------------------------------------------------------------------
# Main page: chat interface
# ----------------------------------------------------------------------
st.title("💬 Aetna Virtual Assistant")
st.caption(
    "Ask about plan coverage, benefits, eligibility, claims, appeals, "
    "prior authorization, and more."
)

# Render prior turns
for turn in st.session_state.chat_log:
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        if turn["role"] == "assistant" and turn.get("sources"):
            st.progress(turn["confidence"], text=f"Confidence: {turn['confidence']:.0%}")
            with st.expander(f"📄 Sources ({len(turn['sources'])})"):
                for src in turn["sources"]:
                    st.markdown(
                        f"**{src.file_name}** — page {src.page_number} "
                        f"(score: {src.score:.2f})"
                    )
                    st.text(src.text[:500] + ("..." if len(src.text) > 500 else ""))

user_question = st.chat_input("Ask a question about your Aetna plan...")

if user_question:
    st.session_state.chat_log.append({"role": "user", "content": user_question})
    with st.chat_message("user"):
        st.markdown(user_question)

    with st.chat_message("assistant"):
        with st.spinner("Looking through your plan documents..."):
            response = st.session_state.pipeline.answer_question(user_question)

        st.markdown(response.answer)
        st.progress(response.confidence, text=f"Confidence: {response.confidence:.0%}")

        if response.sources:
            with st.expander(f"📄 Sources ({len(response.sources)})"):
                for src in response.sources:
                    st.markdown(
                        f"**{src.file_name}** — page {src.page_number} "
                        f"(score: {src.score:.2f})"
                    )
                    st.text(src.text[:500] + ("..." if len(src.text) > 500 else ""))

        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("👍", key=f"up_{len(st.session_state.chat_log)}"):
                log_feedback(
                    FeedbackEvent(
                        question=user_question,
                        answer=response.answer,
                        rating="up",
                        guardrail_flag=response.guardrail_flag,
                    )
                )
                st.toast("Thanks for the feedback!")
        with col2:
            if st.button("👎", key=f"down_{len(st.session_state.chat_log)}"):
                log_feedback(
                    FeedbackEvent(
                        question=user_question,
                        answer=response.answer,
                        rating="down",
                        guardrail_flag=response.guardrail_flag,
                    )
                )
                st.toast("Thanks — we'll use this to improve answers.")

    st.session_state.chat_log.append(
        {
            "role": "assistant",
            "content": response.answer,
            "sources": response.sources,
            "confidence": response.confidence,
        }
    )
