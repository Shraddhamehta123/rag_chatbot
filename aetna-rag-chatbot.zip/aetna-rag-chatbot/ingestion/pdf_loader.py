"""
ingestion/pdf_loader.py
========================
STEP 1 & 2 of the architecture: Load PDFs, Parse PDFs.

WHAT THIS MODULE DOES
-----------------------
Reads Aetna source PDFs (Evidence of Coverage, Summary of Benefits and
Coverage, Medicare Managed Care Manual) page-by-page and extracts plain
text, tagging each page with the metadata the rest of the pipeline needs
downstream (chunking, Delta storage, citations in the UI).

WHY PyMuPDF (imported as `fitz`)
-----------------------------------
- Much faster than pdfminer/PyPDF2 on large regulatory PDFs (some CMS/EOC
  documents run 150+ pages).
- Preserves page boundaries natively, which we need for citations
  ("see EOC page 42") -- some libraries silently concatenate pages.
- Handles PDFs with mixed encodings/scanned cover pages more gracefully.

INPUT / OUTPUT
----------------
Input : a file path (or list of paths) to a .pdf on disk (or DBFS/Volumes
        path when running inside Databricks, e.g. "/Volumes/.../eoc.pdf").
Output: a list of `PageDocument` dataclasses, one per non-empty page,
        each carrying the extracted text + metadata. Downstream chunking
        consumes this list directly.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import fitz  # PyMuPDF

from utils.logging_utils import get_logger

logger = get_logger(__name__)


# Maps a filename fragment to the human-readable document type used in
# citations and metadata filtering. Extend this as new source documents
# are onboarded.
DOCUMENT_TYPE_MAP = {
    "eoc": "Evidence of Coverage",
    "sbc": "Summary of Benefits and Coverage",
    "mmcm": "Medicare Managed Care Manual",
}


@dataclass
class PageDocument:
    """One page of extracted text plus the metadata needed for citations."""

    file_name: str
    document_type: str
    page_number: int  # 1-indexed, matches what a human sees in a PDF viewer
    text: str


def infer_document_type(file_name: str) -> str:
    """
    Best-effort mapping from a filename to a human-readable document type.
    Falls back to "Unknown" rather than raising, so one badly-named file
    doesn't kill an entire ingestion batch.
    """
    lowered = file_name.lower()
    for fragment, doc_type in DOCUMENT_TYPE_MAP.items():
        if fragment in lowered:
            return doc_type
    logger.warning(
        "Could not infer document_type for '%s'; defaulting to 'Unknown'. "
        "Consider adding a mapping in DOCUMENT_TYPE_MAP.",
        file_name,
    )
    return "Unknown"


def load_pdf(file_path: str, document_type: Optional[str] = None) -> List[PageDocument]:
    """
    Extract text from a single PDF, one page at a time.

    Parameters
    ----------
    file_path : str
        Path to the PDF (local, DBFS, or Unity Catalog Volumes path).
    document_type : Optional[str]
        Override for the inferred document type. Pass explicitly when the
        filename doesn't follow the eoc/sbc/mmcm naming convention.

    Returns
    -------
    List[PageDocument]
        One entry per page that contains extractable text. Blank pages
        (e.g. section dividers) are skipped to avoid polluting the index
        with empty chunks.

    ERROR HANDLING
    ---------------
    - A corrupt/unreadable PDF logs an error and returns an empty list
      rather than crashing the whole ingestion job -- one bad file
      shouldn't block 50 good ones in a batch run.
    - Per-page extraction errors (rare, usually malformed page objects)
      are caught individually so one bad page doesn't lose the rest of
      an otherwise-good document.
    """
    file_name = Path(file_path).name
    resolved_doc_type = document_type or infer_document_type(file_name)
    pages: List[PageDocument] = []

    try:
        doc = fitz.open(file_path)
    except Exception as exc:
        logger.error("Failed to open PDF '%s': %s", file_path, exc)
        return pages

    try:
        logger.info(
            "Opened '%s' (%d pages) as document_type='%s'",
            file_name,
            doc.page_count,
            resolved_doc_type,
        )

        for page_index in range(doc.page_count):
            page_number = page_index + 1  # human-friendly, 1-indexed
            try:
                page = doc.load_page(page_index)
                # "text" extraction mode preserves reading order reasonably
                # well for the mostly single-column layout of EOC/SBC docs.
                text = page.get_text("text").strip()
            except Exception as exc:
                logger.error(
                    "Failed to extract text from '%s' page %d: %s. Skipping page.",
                    file_name,
                    page_number,
                    exc,
                )
                continue

            if not text:
                # Common for cover pages, section dividers, blank backs.
                logger.debug("Page %d of '%s' had no extractable text; skipping.", page_number, file_name)
                continue

            pages.append(
                PageDocument(
                    file_name=file_name,
                    document_type=resolved_doc_type,
                    page_number=page_number,
                    text=text,
                )
            )
    finally:
        # Always release the file handle, even if extraction raised.
        doc.close()

    logger.info("Extracted %d non-empty pages from '%s'.", len(pages), file_name)
    return pages


def load_pdfs(file_paths: List[str]) -> List[PageDocument]:
    """
    Batch entry point: loads multiple PDFs and flattens the result into a
    single list of PageDocuments, ready for chunking.

    A failure on any one file is logged and skipped (see `load_pdf`);
    the batch as a whole always returns whatever succeeded, which is the
    right behavior for a nightly ingestion job over dozens of CMS/plan
    documents.
    """
    all_pages: List[PageDocument] = []
    for path in file_paths:
        all_pages.extend(load_pdf(path))
    logger.info(
        "Batch ingestion complete: %d files requested, %d total pages extracted.",
        len(file_paths),
        len(all_pages),
    )
    return all_pages
