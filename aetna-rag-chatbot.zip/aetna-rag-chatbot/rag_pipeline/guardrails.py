"""
rag_pipeline/guardrails.py
=============================
Enhancement 6: Guardrails.

Two layers of protection:

1. INPUT guardrails -- catch things we should refuse before spending an
   LLM call: attempts to extract the system prompt, prompt injection
   patterns embedded in a "question", or requests for medical advice
   rather than coverage information.

2. OUTPUT guardrails -- verify the generated answer actually contains a
   citation (unless it's the "not found" fallback) and doesn't leak the
   system prompt verbatim. This is a cheap regex-based safety net on top
   of the prompt-level instructions in `prompt_templates.py` -- prompts
   alone are not a reliable enforcement mechanism.

This is intentionally simple/regex-based rather than a full guardrails
framework (e.g. NeMo Guardrails, Guardrails AI) to keep the reference
implementation dependency-light; swap in a dedicated library for a real
production deployment handling adversarial traffic at scale.
"""

import re
from dataclasses import dataclass
from typing import Optional

from rag_pipeline.prompt_templates import NOT_FOUND_MESSAGE, SYSTEM_PROMPT
from utils.logging_utils import get_logger

logger = get_logger(__name__)


PROMPT_INJECTION_PATTERNS = [
    r"ignore (all|any|previous) instructions",
    r"you are now",
    r"reveal (your|the) (system|prompt)",
    r"repeat (your|the) (system|prompt)",
    r"act as (?!an aetna)",  # allow the legitimate "act as" persona we set
]

MEDICAL_ADVICE_PATTERNS = [
    r"should i (have|get|take|undergo)",
    r"is it safe for me to",
    r"what medication should i",
    r"diagnose",
]


@dataclass
class GuardrailResult:
    allowed: bool
    reason: Optional[str] = None
    safe_response: Optional[str] = None


def check_input(question: str) -> GuardrailResult:
    """
    Runs input-side guardrail checks before the question reaches
    retrieval/generation.
    """
    lowered = question.lower()

    for pattern in PROMPT_INJECTION_PATTERNS:
        if re.search(pattern, lowered):
            logger.warning("Blocked potential prompt injection: '%s'", question[:100])
            return GuardrailResult(
                allowed=False,
                reason="prompt_injection",
                safe_response=(
                    "I can only help with questions about your Aetna plan "
                    "coverage, benefits, and claims. I'm not able to change "
                    "how I operate based on chat instructions."
                ),
            )

    for pattern in MEDICAL_ADVICE_PATTERNS:
        if re.search(pattern, lowered):
            logger.info("Redirecting medical-advice-shaped question: '%s'", question[:100])
            return GuardrailResult(
                allowed=False,
                reason="medical_advice",
                safe_response=(
                    "I can only speak to what your plan covers and the "
                    "associated costs -- I'm not able to give medical advice "
                    "or recommend treatment. Please talk to your doctor "
                    "about what's medically right for you, and I'm happy to "
                    "look up whether a specific service or procedure is "
                    "covered."
                ),
            )

    return GuardrailResult(allowed=True)


def check_output(answer: str) -> GuardrailResult:
    """
    Runs output-side guardrail checks after generation, before the answer
    is shown to the user.
    """
    # Don't let the model leak the raw system prompt even if a clever
    # jailbreak got past input guardrails.
    if SYSTEM_PROMPT[:60].lower() in answer.lower():
        logger.error("Blocked a response that leaked the system prompt.")
        return GuardrailResult(
            allowed=False,
            reason="system_prompt_leak",
            safe_response=NOT_FOUND_MESSAGE,
        )

    is_fallback = answer.strip() == NOT_FOUND_MESSAGE
    has_citation = bool(re.search(r"\[Source:.*?page \d+\]", answer))

    if not is_fallback and not has_citation:
        logger.warning("Answer produced without a citation; flagging for review.")
        # We don't block the answer outright (that would make the bot
        # unusable on legitimately well-grounded answers where the model
        # forgot the exact citation format) -- but we flag it so
        # `utils/feedback_logger.py` can surface it for QA review.
        return GuardrailResult(allowed=True, reason="missing_citation")

    return GuardrailResult(allowed=True)
