"""
rag_pipeline/prompt_templates.py
==================================
Centralized prompt definitions. Keeping every prompt string in ONE file
means (a) prompt-engineering changes never require touching pipeline
logic, and (b) MLflow can log/version this file's content alongside each
experiment run for reproducibility.

DESIGN NOTES
-------------
- The system prompt explicitly forbids answering from anything except the
  retrieved context ("grounding") -- this is the single most important
  guardrail against hallucinated benefits information.
- The "not found" fallback string is returned VERBATIM when retrieval
  confidence is low, so the UI/tests can reliably detect it
  (see `rag_pipeline.py::generate_answer`).
- Citations are requested inline as `[Source: <file>, page <n>]` so the
  Streamlit UI can regex-parse and turn them into the expandable source
  viewer, in addition to the structured `sources` list already returned
  by `RetrievalService`.
"""

NOT_FOUND_MESSAGE = "I could not find this information in the available documents."

SYSTEM_PROMPT = f"""You are an Aetna Insurance Assistant.

Your job is to answer questions from Aetna Medicare members, providers,
and internal staff using ONLY the context provided below, which is
retrieved from official plan documents (Evidence of Coverage, Summary of
Benefits and Coverage, and the Medicare Managed Care Manual).

Rules you must always follow:
1. Answer ONLY using the retrieved context. Do not use outside knowledge
   about Aetna, Medicare, or insurance in general, even if you believe it
   to be true.
2. Do NOT hallucinate or infer numbers, dates, or coverage rules that are
   not explicitly present in the context.
3. Always cite the source document and page number for every factual
   claim, in the format: [Source: <document_name>, page <page_number>].
4. If the context does not contain enough information to answer the
   question, respond with EXACTLY this sentence and nothing else:
   "{NOT_FOUND_MESSAGE}"
5. Do not provide medical advice. If asked a clinical question (e.g.
   "should I have this surgery"), clarify that you can only speak to
   coverage and plan rules, not medical recommendations.
6. Be concise, plain-language, and empathetic -- many members reading
   your answers are dealing with a stressful health or financial
   situation.
"""

ANSWER_PROMPT_TEMPLATE = """Context from Aetna plan documents:
---------------------
{context}
---------------------

Conversation history (most recent last):
{history}

Member/Provider question: {question}

Answer the question following all system rules. Include citations for
every factual claim. If the context is insufficient, respond with the
exact fallback sentence specified in your instructions."""


QUERY_REWRITE_PROMPT_TEMPLATE = """Given the conversation history and a
follow-up question, rewrite the follow-up question into a standalone
question that contains all context needed to answer it without seeing
the history. Do not answer the question -- only rewrite it.

Conversation history:
{history}

Follow-up question: {question}

Standalone question:"""


def build_context_block(chunks: list) -> str:
    """
    Formats retrieved chunks into the `{context}` block injected into
    `ANSWER_PROMPT_TEMPLATE`. Each chunk is tagged with its source so the
    LLM can produce accurate inline citations.

    Parameters
    ----------
    chunks : list[rag_pipeline.retrieval_service.RetrievedChunk]

    Returns
    -------
    str
    """
    blocks = []
    for chunk in chunks:
        blocks.append(
            f"[Source: {chunk.file_name}, page {chunk.page_number}]\n{chunk.text}"
        )
    return "\n\n".join(blocks)


def build_history_block(history: list) -> str:
    """
    Formats prior conversation turns for the memory-augmented prompt.
    `history` is a list of (role, content) tuples from
    `rag_pipeline.memory.ConversationMemory`.
    """
    if not history:
        return "(no prior conversation)"
    lines = [f"{role.upper()}: {content}" for role, content in history]
    return "\n".join(lines)
