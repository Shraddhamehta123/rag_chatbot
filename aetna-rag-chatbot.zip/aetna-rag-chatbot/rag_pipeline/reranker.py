"""
rag_pipeline/reranker.py
===========================
Enhancement 4: Reranking.

WHY THIS IS NEEDED
--------------------
Vector similarity search is fast but approximate -- it's optimized to
find candidates quickly across millions of vectors, not to perfectly
rank the top handful. A cross-encoder reranker looks at the (query,
chunk) PAIR directly (rather than comparing two independently-computed
vectors) and produces a much more accurate relevance score for the small
candidate set we actually care about (typically top_k * 3 candidates ->
reranked down to top_k).

IMPLEMENTATION NOTE
---------------------
This uses an LLM-as-reranker approach (a single batched GPT-4o call that
scores each candidate 0-10) to avoid adding a second model-serving
dependency (e.g. a dedicated cross-encoder endpoint) to the architecture.
For very high query volume, swap this for a dedicated Databricks
Model Serving cross-encoder endpoint (e.g. bge-reranker) -- the
`Reranker` interface below is designed so that swap doesn't touch
calling code.
"""

import json
from typing import List

from openai import AzureOpenAI

from config.settings import settings
from rag_pipeline.retrieval_service import RetrievedChunk
from utils.logging_utils import get_logger

logger = get_logger(__name__)

RERANK_PROMPT = """You are scoring how relevant each document excerpt is
to a user's question, on a scale of 0 (irrelevant) to 10 (directly
answers the question).

Question: {question}

Excerpts:
{excerpts}

Respond with ONLY a JSON array of integers, one score per excerpt, in the
same order. Example: [8, 2, 9, 0, 5]"""


class Reranker:
    """Reorders retrieved chunks by (query, chunk) relevance."""

    def __init__(self, client: AzureOpenAI = None):
        self.client = client or AzureOpenAI(
            api_key=settings.azure_openai_key,
            api_version=settings.azure_openai_api_version,
            azure_endpoint=settings.azure_openai_endpoint,
        )

    def rerank(
        self, question: str, chunks: List[RetrievedChunk], top_k: int
    ) -> List[RetrievedChunk]:
        """
        Rescore and reorder `chunks`, returning the top `top_k`.
        Fails open: if the reranker call errors or returns malformed
        JSON, the original vector-search ordering is preserved so a
        reranker outage never breaks the pipeline.
        """
        if not chunks:
            return chunks

        excerpts_block = "\n\n".join(
            f"[{i}] {chunk.text[:500]}" for i, chunk in enumerate(chunks)
        )
        prompt = RERANK_PROMPT.format(question=question, excerpts=excerpts_block)

        try:
            response = self.client.chat.completions.create(
                model=settings.chat_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=200,
            )
            raw = response.choices[0].message.content.strip()
            scores = json.loads(raw)
            if len(scores) != len(chunks):
                raise ValueError("Score count does not match chunk count.")
        except Exception as exc:
            logger.warning("Reranking failed (%s); returning original order.", exc)
            return chunks[:top_k]

        scored = list(zip(chunks, scores))
        scored.sort(key=lambda pair: pair[1], reverse=True)
        reranked = [chunk for chunk, _ in scored][:top_k]

        logger.info("Reranked %d candidates -> top %d.", len(chunks), len(reranked))
        return reranked
