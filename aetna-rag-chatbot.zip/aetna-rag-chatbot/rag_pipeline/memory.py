"""
rag_pipeline/memory.py
========================
Enhancement 1: Conversational Memory.

WHY THIS IS NEEDED
--------------------
Members ask natural follow-ups: "What's my deductible?" then "...and what
about for specialists?" Without memory, the second question is
unanswerable in isolation. We keep a short rolling window of turns (not
the entire history) both to control prompt-token cost and because very
old turns are rarely relevant to the current question in a
benefits-lookup chatbot.
"""

from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass
class ConversationMemory:
    """
    Simple bounded conversational memory.

    `max_turns` counts USER+ASSISTANT pairs, not individual messages --
    e.g. max_turns=5 keeps the last 5 question/answer exchanges (10
    messages) in context.
    """

    max_turns: int = 5
    _history: List[Tuple[str, str]] = field(default_factory=list)

    def add_turn(self, role: str, content: str) -> None:
        """role is 'user' or 'assistant'."""
        self._history.append((role, content))
        # Trim to the last max_turns*2 messages.
        limit = self.max_turns * 2
        if len(self._history) > limit:
            self._history = self._history[-limit:]

    def get_history(self) -> List[Tuple[str, str]]:
        return list(self._history)

    def clear(self) -> None:
        """Backs the Streamlit UI's 'Clear chat' button."""
        self._history = []

    def last_user_question(self) -> str:
        for role, content in reversed(self._history):
            if role == "user":
                return content
        return ""
