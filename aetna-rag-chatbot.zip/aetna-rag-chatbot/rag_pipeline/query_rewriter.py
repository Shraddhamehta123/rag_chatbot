"""
rag_pipeline/query_rewriter.py
=================================
Enhancement 3: Query Rewriting.

WHY THIS IS NEEDED
--------------------
Retrieval (embedding similarity search) works on the LITERAL text of the
query. A follow-up like "what about specialists?" embeds poorly on its
own -- it's missing the subject ("deductible", "copay") from the previous
turn. This module uses a fast/cheap LLM call to rewrite such follow-ups
into standalone questions BEFORE they hit `RetrievalService`, which
meaningfully improves recall on multi-turn conversations.

We only rewrite when there IS conversation history; a first-turn question
is already standalone and skipping the rewrite call saves latency/cost.
"""

from typing import List, Tuple

from openai import AzureOpenAI

from config.settings import settings
from rag_pipeline.prompt_templates import QUERY_REWRITE_PROMPT_TEMPLATE, build_history_block
from utils.logging_utils import get_logger

logger = get_logger(__name__)


def rewrite_query(
    question: str,
    history: List[Tuple[str, str]],
    client: AzureOpenAI = None,
) -> str:
    """
    Rewrites `question` into a standalone question using `history` as
    context. Returns `question` unchanged if there's no history, or if
    the rewrite call fails (fail-open: a bad rewrite call should degrade
    to "search with the original question", not break the whole turn).
    """
    if not history:
        return question

    client = client or AzureOpenAI(
        api_key=settings.azure_openai_key,
        api_version=settings.azure_openai_api_version,
        azure_endpoint=settings.azure_openai_endpoint,
    )

    prompt = QUERY_REWRITE_PROMPT_TEMPLATE.format(
        history=build_history_block(history), question=question
    )

    try:
        response = client.chat.completions.create(
            model=settings.chat_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
            max_tokens=100,
        )
        rewritten = response.choices[0].message.content.strip()
        logger.debug("Rewrote query '%s' -> '%s'", question, rewritten)
        return rewritten or question
    except Exception as exc:
        logger.warning("Query rewrite failed (%s); falling back to original question.", exc)
        return question
