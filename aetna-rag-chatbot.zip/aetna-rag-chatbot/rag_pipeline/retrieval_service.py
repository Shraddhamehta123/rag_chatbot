"""
rag_pipeline/retrieval_service.py
====================================
STEP 7 of the architecture: Retrieve Top K Chunks.

Also implements Enhancement 2 (Hybrid Search): vector similarity search
combined with a keyword (BM25-style) pass over `chunk_text`, since pure
embedding search sometimes misses exact-match lookups that matter a lot
in insurance docs -- e.g. a member asking about a specific CPT/HCPCS
code or an exact plan name performs better with keyword matching than
pure semantic similarity.
"""

from dataclasses import dataclass
from typing import List, Optional

from databricks.vector_search.client import VectorSearchClient

from config.settings import settings
from utils.logging_utils import get_logger
from vector_search.vector_index_manager import get_vs_client

logger = get_logger(__name__)


@dataclass
class RetrievedChunk:
    """A chunk returned from retrieval, with its similarity score and provenance."""

    chunk_id: str
    text: str
    file_name: str
    document_type: str
    page_number: int
    score: float


class RetrievalService:
    """
    Reusable retrieval service wrapping Databricks Vector Search.

    Parameters
    ----------
    top_k : int
        Number of chunks to retrieve per query (default from Settings: 5).
    score_threshold : float
        Minimum similarity score (0-1, cosine) for a chunk to be kept.
        Chunks below this are dropped -- this is what lets
        `RAGPipeline.generate_answer` correctly emit the "not found"
        fallback instead of grounding an answer in barely-related text.
    enable_hybrid : bool
        When True, blends vector search results with a keyword filter
        pass (Enhancement 2).
    """

    def __init__(
        self,
        top_k: int = None,
        score_threshold: float = None,
        enable_hybrid: bool = False,
        vs_client: Optional[VectorSearchClient] = None,
    ):
        self.top_k = top_k or settings.default_top_k
        self.score_threshold = (
            score_threshold if score_threshold is not None else settings.default_score_threshold
        )
        self.enable_hybrid = enable_hybrid
        self.vs_client = vs_client or get_vs_client()

    def _vector_search(self, query: str, top_k: int) -> List[RetrievedChunk]:
        """
        Runs the actual Databricks Vector Search query. We pass the raw
        query text -- because the index was created with
        `sync_computed_embeddings=False` for our OWN pre-computed
        chunk embeddings, query-time embedding for the search call itself
        is handled by passing `query_text` and letting Vector Search's
        query-embedding model embed it, OR (recommended for strict model
        consistency) by pre-embedding the query ourselves with
        `embeddings.embedding_service.generate_embeddings` and passing
        `query_vector` instead. We do the latter here for consistency
        with the ingestion-time embedding model.
        """
        from embeddings.embedding_service import generate_embeddings

        query_vector = generate_embeddings([query])[0]

        index = self.vs_client.get_index(
            endpoint_name=settings.vector_search_endpoint_name,
            index_name=settings.vector_search_index_name,
        )

        results = index.similarity_search(
            query_vector=query_vector,
            columns=["chunk_id", "chunk_text", "document_name", "document_type", "page_number"],
            num_results=top_k,
        )

        rows = results.get("result", {}).get("data_array", [])
        retrieved = []
        for row in rows:
            # Column order matches the `columns` list above, with the
            # similarity score appended as the last element by the API.
            chunk_id, chunk_text, document_name, document_type, page_number, score = row
            retrieved.append(
                RetrievedChunk(
                    chunk_id=chunk_id,
                    text=chunk_text,
                    file_name=document_name,
                    document_type=document_type,
                    page_number=int(page_number),
                    score=float(score),
                )
            )
        return retrieved

    def _keyword_filter_boost(
        self, query: str, candidates: List[RetrievedChunk]
    ) -> List[RetrievedChunk]:
        """
        Lightweight lexical boost: chunks that literally contain one of
        the query's significant words get a small score bump. This is a
        pragmatic hybrid approach that doesn't require standing up a
        separate BM25/Elasticsearch service -- good enough to break ties
        in favor of exact-term matches (plan names, code numbers) while
        Databricks' native BM25 index support is still maturing.
        """
        query_terms = {t.lower() for t in query.split() if len(t) > 3}
        if not query_terms:
            return candidates

        boosted = []
        for chunk in candidates:
            text_lower = chunk.text.lower()
            hits = sum(1 for term in query_terms if term in text_lower)
            boost = min(hits * 0.02, 0.10)  # cap the keyword boost at +0.10
            boosted.append(
                RetrievedChunk(
                    chunk_id=chunk.chunk_id,
                    text=chunk.text,
                    file_name=chunk.file_name,
                    document_type=chunk.document_type,
                    page_number=chunk.page_number,
                    score=min(chunk.score + boost, 1.0),
                )
            )
        return boosted

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None,
        score_threshold: Optional[float] = None,
        document_type_filter: Optional[str] = None,
    ) -> List[RetrievedChunk]:
        """
        Main entry point used by `RAGPipeline.retrieve()`.

        Parameters
        ----------
        query : str
            The (possibly rewritten -- see `query_rewriter.py`) question.
        top_k : Optional[int]
            Overrides the instance default for this call.
        score_threshold : Optional[int]
            Overrides the instance default for this call.
        document_type_filter : Optional[str]
            Restrict results to one document type, e.g. "Summary of
            Benefits and Coverage" -- used when the UI lets a user narrow
            their search.

        Returns
        -------
        List[RetrievedChunk]
            Sorted descending by score, filtered to those >= threshold,
            capped at top_k.
        """
        top_k = top_k or self.top_k
        score_threshold = score_threshold if score_threshold is not None else self.score_threshold

        # Over-fetch before filtering so the keyword boost / doc-type
        # filter has enough candidates to work with.
        raw_results = self._vector_search(query, top_k=max(top_k * 3, top_k))

        if document_type_filter:
            raw_results = [r for r in raw_results if r.document_type == document_type_filter]

        if self.enable_hybrid:
            raw_results = self._keyword_filter_boost(query, raw_results)

        filtered = [r for r in raw_results if r.score >= score_threshold]
        filtered.sort(key=lambda r: r.score, reverse=True)
        top_results = filtered[:top_k]

        logger.info(
            "Retrieved %d/%d candidate chunks above threshold=%.2f for query='%s'.",
            len(top_results),
            len(raw_results),
            score_threshold,
            query[:80],
        )
        return top_results
