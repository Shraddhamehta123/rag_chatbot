"""
rag_pipeline/rag_pipeline.py
===============================
STEPS 7-9 of the architecture: Retrieve Top K Chunks, Ground LLM Response
Using Retrieved Context, Return Answer with Citations.

This is the class the Streamlit frontend (and any future channel -- an
API, a Teams bot, etc.) calls into. Everything else in `rag_pipeline/`
and `embeddings/`/`vector_search/` is a building block this class
composes.
"""

from dataclasses import dataclass
from typing import List, Optional

from openai import AzureOpenAI

from config.settings import settings
from rag_pipeline.guardrails import check_input, check_output
from rag_pipeline.memory import ConversationMemory
from rag_pipeline.prompt_templates import (
    ANSWER_PROMPT_TEMPLATE,
    NOT_FOUND_MESSAGE,
    SYSTEM_PROMPT,
    build_context_block,
    build_history_block,
)
from rag_pipeline.query_rewriter import rewrite_query
from rag_pipeline.reranker import Reranker
from rag_pipeline.retrieval_service import RetrievalService, RetrievedChunk
from utils.logging_utils import get_logger
from utils.mlflow_tracking import log_token_usage, trace_rag_request

logger = get_logger(__name__)


@dataclass
class RAGResponse:
    """Everything the Streamlit UI needs to render one chatbot turn."""

    answer: str
    sources: List[RetrievedChunk]
    confidence: float  # top retrieved chunk's similarity score, 0-1
    was_grounded: bool  # False if we returned the "not found" fallback
    guardrail_flag: Optional[str] = None


class RAGPipeline:
    """
    Orchestrates one question -> answer turn.

    Parameters
    ----------
    top_k : int
        Chunks to retrieve (and, after optional reranking, feed to the LLM).
    score_threshold : float
        Minimum similarity for a chunk to be considered relevant.
    enable_hybrid_search : bool
        Enhancement 2 toggle.
    enable_reranking : bool
        Enhancement 4 toggle.
    enable_query_rewriting : bool
        Enhancement 3 toggle -- rewrites follow-up questions using memory.
    memory : Optional[ConversationMemory]
        Enhancement 1 -- pass a shared instance to persist across turns in
        a Streamlit session (`st.session_state`).
    """

    def __init__(
        self,
        top_k: int = None,
        score_threshold: float = None,
        enable_hybrid_search: bool = True,
        enable_reranking: bool = True,
        enable_query_rewriting: bool = True,
        memory: Optional[ConversationMemory] = None,
    ):
        self.top_k = top_k or settings.default_top_k
        self.score_threshold = (
            score_threshold if score_threshold is not None else settings.default_score_threshold
        )
        self.enable_reranking = enable_reranking
        self.enable_query_rewriting = enable_query_rewriting
        self.memory = memory or ConversationMemory()

        self.retrieval_service = RetrievalService(
            top_k=self.top_k,
            score_threshold=self.score_threshold,
            enable_hybrid=enable_hybrid_search,
        )
        self.reranker = Reranker() if enable_reranking else None

        settings.validate()
        self.llm_client = AzureOpenAI(
            api_key=settings.azure_openai_key,
            api_version=settings.azure_openai_api_version,
            azure_endpoint=settings.azure_openai_endpoint,
        )

    # ------------------------------------------------------------------
    # Pipeline methods (each maps directly to one architecture step)
    # ------------------------------------------------------------------

    def retrieve(self, question: str) -> List[RetrievedChunk]:
        """
        STEP 7. Optionally rewrites the question using conversation
        history first (Enhancement 3), retrieves candidates, then
        reranks (Enhancement 4) if enabled.
        """
        search_query = question
        if self.enable_query_rewriting:
            search_query = rewrite_query(question, self.memory.get_history())

        # Over-fetch when reranking so the reranker has real signal to
        # work with, then trim back down to top_k.
        fetch_k = self.top_k * 3 if self.reranker else self.top_k
        candidates = self.retrieval_service.retrieve(search_query, top_k=fetch_k)

        if self.reranker and candidates:
            candidates = self.reranker.rerank(search_query, candidates, top_k=self.top_k)

        return candidates[: self.top_k]

    def build_context(self, chunks: List[RetrievedChunk]) -> str:
        """STEP 8 (part 1). Formats retrieved chunks for prompt injection."""
        return build_context_block(chunks)

    def generate_answer(self, question: str, context: str) -> str:
        """
        STEP 8 (part 2) & STEP 9. Calls GPT-4o with the grounded prompt
        and returns the raw answer text (citations included inline, per
        the system prompt's formatting rules).
        """
        prompt = ANSWER_PROMPT_TEMPLATE.format(
            context=context if context.strip() else "(no relevant context retrieved)",
            history=build_history_block(self.memory.get_history()),
            question=question,
        )

        response = self.llm_client.chat.completions.create(
            model=settings.chat_model,  # "gpt-4o"
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,  # low temperature: consistency matters more than variety here
            max_tokens=800,
        )

        if response.usage:
            log_token_usage(response.usage.prompt_tokens, response.usage.completion_tokens)

        return response.choices[0].message.content.strip()

    def answer_question(self, question: str) -> RAGResponse:
        """
        Full end-to-end turn: retrieve -> build_context -> generate_answer,
        wrapped in guardrails, MLflow tracing, and conversational memory
        bookkeeping. This is the ONE method the Streamlit UI calls.
        """
        with trace_rag_request(question) as trace:
            # --- Input guardrails ---
            input_check = check_input(question)
            if not input_check.allowed:
                trace.log_param("guardrail_blocked", input_check.reason)
                return RAGResponse(
                    answer=input_check.safe_response,
                    sources=[],
                    confidence=0.0,
                    was_grounded=False,
                    guardrail_flag=input_check.reason,
                )

            # --- Retrieve ---
            chunks = self.retrieve(question)
            trace.log_metric("num_chunks_retrieved", len(chunks))
            trace.log_param("top_k", self.top_k)
            trace.log_param("score_threshold", self.score_threshold)

            if not chunks:
                logger.info("No chunks cleared the score threshold; returning fallback.")
                answer = NOT_FOUND_MESSAGE
                self.memory.add_turn("user", question)
                self.memory.add_turn("assistant", answer)
                return RAGResponse(
                    answer=answer, sources=[], confidence=0.0, was_grounded=False
                )

            # --- Build context + generate ---
            context = self.build_context(chunks)
            answer = self.generate_answer(question, context)

            # --- Output guardrails ---
            output_check = check_output(answer)
            if not output_check.allowed:
                answer = output_check.safe_response

            self.memory.add_turn("user", question)
            self.memory.add_turn("assistant", answer)

            confidence = chunks[0].score if chunks else 0.0
            trace.log_metric("confidence", confidence)

            return RAGResponse(
                answer=answer,
                sources=chunks,
                confidence=confidence,
                was_grounded=answer.strip() != NOT_FOUND_MESSAGE,
                guardrail_flag=output_check.reason,
            )
