"""
config/settings.py
===================
Centralized configuration for the Aetna Virtual Assistant RAG stack.

WHY THIS FILE EXISTS
---------------------
Every other module imports `Settings` instead of reading environment
variables or secrets directly. This gives us ONE place to change when we
move from dev -> staging -> prod, and it means no file in this codebase
ever hardcodes an API key, endpoint, or credential (a hard security
requirement for anything touching insurance/PHI-adjacent data).

DATABRICKS CONCEPT: Secret Scopes
----------------------------------
A "Secret Scope" is Databricks' encrypted key-value store for credentials.
Secrets are written once via the CLI/API (never in notebook code):

    databricks secrets create-scope aetna-rag
    databricks secrets put-secret aetna-rag azure-openai-key
    databricks secrets put-secret aetna-rag azure-openai-endpoint
    databricks secrets put-secret aetna-rag databricks-host
    databricks secrets put-secret aetna-rag databricks-token
    databricks secrets put-secret aetna-rag vector-search-endpoint

At runtime, notebooks/jobs read them with:

    dbutils.secrets.get(scope="aetna-rag", key="azure-openai-key")

`dbutils` only exists inside a Databricks runtime, so this module falls
back to environment variables when running locally (e.g. unit tests on a
laptop / CI runner), which keeps the code portable and testable.
"""

import os
from dataclasses import dataclass, field
from typing import Optional


def _get_secret(scope: str, key: str, env_fallback: str) -> Optional[str]:
    """
    Try Databricks Secret Scope first, then fall back to an environment
    variable. This lets the exact same code run inside a Databricks
    notebook/job AND in a local pytest run / CI pipeline.

    Parameters
    ----------
    scope : str
        Name of the Databricks Secret Scope (e.g. "aetna-rag").
    key : str
        Name of the secret within that scope.
    env_fallback : str
        Environment variable name to check if `dbutils` isn't available.

    Returns
    -------
    Optional[str]
        The secret value, or None if not found anywhere (caller decides
        whether that's fatal).
    """
    try:
        # dbutils is injected automatically into the notebook/job namespace
        # by the Databricks runtime -- it does NOT exist in plain Python.
        from pyspark.dbutils import DBUtils  # type: ignore
        from pyspark.sql import SparkSession

        spark = SparkSession.getActiveSession()
        if spark is not None:
            dbutils = DBUtils(spark)
            return dbutils.secrets.get(scope=scope, key=key)
    except Exception:
        # Not running on a Databricks cluster, or dbutils unavailable.
        # This is expected locally -- fall through to env vars.
        pass

    return os.environ.get(env_fallback)


@dataclass(frozen=True)
class Settings:
    """
    Immutable configuration object. `frozen=True` prevents any code path
    from accidentally mutating shared config mid-run.
    """

    # --- Azure OpenAI ---
    azure_openai_endpoint: str = field(
        default_factory=lambda: _get_secret(
            "aetna-rag", "azure-openai-endpoint", "AZURE_OPENAI_ENDPOINT"
        )
        or ""
    )
    azure_openai_key: str = field(
        default_factory=lambda: _get_secret(
            "aetna-rag", "azure-openai-key", "AZURE_OPENAI_KEY"
        )
        or ""
    )
    azure_openai_api_version: str = "2024-08-01-preview"
    embedding_model: str = "text-embedding-3-large"
    chat_model: str = "gpt-4o"

    # --- Databricks / Unity Catalog ---
    databricks_host: str = field(
        default_factory=lambda: _get_secret(
            "aetna-rag", "databricks-host", "DATABRICKS_HOST"
        )
        or ""
    )
    databricks_token: str = field(
        default_factory=lambda: _get_secret(
            "aetna-rag", "databricks-token", "DATABRICKS_TOKEN"
        )
        or ""
    )
    uc_catalog: str = "aetna_rag_catalog"
    uc_schema: str = "virtual_assistant"
    delta_table_name: str = "document_chunks"

    # --- Vector Search ---
    vector_search_endpoint_name: str = "aetna_rag_vs_endpoint"
    vector_search_index_name: str = "aetna_rag_catalog.virtual_assistant.document_chunks_index"

    # --- Chunking ---
    chunk_size: int = 1000
    chunk_overlap: int = 200

    # --- Retrieval ---
    default_top_k: int = 5
    default_score_threshold: float = 0.70

    # --- MLflow ---
    mlflow_experiment_name: str = "/Shared/aetna-rag/virtual-assistant"

    @property
    def full_delta_table_path(self) -> str:
        return f"{self.uc_catalog}.{self.uc_schema}.{self.delta_table_name}"

    def validate(self) -> None:
        """
        Fail fast and loud if required secrets are missing, rather than
        letting a downstream Azure OpenAI call fail with a cryptic 401.
        """
        missing = [
            name
            for name, value in [
                ("azure_openai_endpoint", self.azure_openai_endpoint),
                ("azure_openai_key", self.azure_openai_key),
            ]
            if not value
        ]
        if missing:
            raise EnvironmentError(
                f"Missing required configuration: {missing}. "
                "Populate the 'aetna-rag' Databricks Secret Scope, or set "
                "the equivalent environment variables for local runs."
            )


# Single shared instance imported everywhere else, e.g.:
#   from config.settings import settings
settings = Settings()
