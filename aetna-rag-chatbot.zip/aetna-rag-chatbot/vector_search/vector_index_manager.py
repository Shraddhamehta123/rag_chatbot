"""
vector_search/vector_index_manager.py
=======================================
STEP 6 of the architecture: Create Databricks Vector Search Index.

DATABRICKS CONCEPT: Vector Search Endpoint vs. Index
-------------------------------------------------------
- **Endpoint**: the serving infrastructure (think "the cluster that will
  answer similarity-search queries"). You create this once per
  environment/workspace and multiple indexes can share it.
- **Index**: the actual searchable structure built over a specific Delta
  table + vector column. We use a **Delta Sync Index**, which means
  Databricks automatically keeps the index in sync with the source Delta
  table's Change Data Feed -- so re-running the ingestion pipeline
  (Steps 1-5) is enough; we never manually push vectors into the index.

We use `pipeline_type="TRIGGERED"` (sync on demand, via
`sync_index_if_needed`) rather than `CONTINUOUS`, because insurance
document updates happen a few times a year (plan-year renewals), not
continuously -- `TRIGGERED` avoids paying for an always-on sync compute
for a slowly-changing corpus.
"""

from typing import Optional

from databricks.vector_search.client import VectorSearchClient

from config.settings import settings
from utils.logging_utils import get_logger

logger = get_logger(__name__)


def get_vs_client() -> VectorSearchClient:
    """
    Lazily construct the Vector Search client. Uses the Databricks
    workspace auth already configured on the cluster (or the
    databricks-host/token secrets when running from a job outside the
    workspace context).
    """
    if settings.databricks_host and settings.databricks_token:
        return VectorSearchClient(
            workspace_url=settings.databricks_host,
            personal_access_token=settings.databricks_token,
        )
    # On a Databricks cluster, the client can auto-detect workspace auth.
    return VectorSearchClient()


def create_endpoint_if_not_exists(client: Optional[VectorSearchClient] = None) -> None:
    """
    Creates the Vector Search endpoint if it doesn't already exist.
    Idempotent -- safe to call every deployment run.
    """
    client = client or get_vs_client()
    endpoint_name = settings.vector_search_endpoint_name

    existing = [ep["name"] for ep in client.list_endpoints().get("endpoints", [])]
    if endpoint_name in existing:
        logger.info("Vector Search endpoint '%s' already exists.", endpoint_name)
        return

    logger.info("Creating Vector Search endpoint '%s'...", endpoint_name)
    client.create_endpoint(name=endpoint_name, endpoint_type="STANDARD")
    logger.info("Endpoint '%s' created.", endpoint_name)


def create_index_if_not_exists(client: Optional[VectorSearchClient] = None) -> None:
    """
    Creates a Delta Sync Index over the chunk table, using the
    `embedding_vector` column we populated in `delta_table_manager.py`.

    `sync_computed_embeddings=False` because we already compute
    embeddings ourselves via Azure OpenAI (Step 4) -- we are NOT asking
    Databricks to compute its own embeddings from `chunk_text`. This
    matters: it keeps embedding generation on the exact same model
    (`text-embedding-3-large`) at both ingestion time and query time,
    which is required for cosine similarity to be meaningful.
    """
    client = client or get_vs_client()
    endpoint_name = settings.vector_search_endpoint_name
    index_name = settings.vector_search_index_name
    source_table = settings.full_delta_table_path

    existing_indexes = [
        idx["name"] for idx in client.list_indexes(endpoint_name).get("vector_indexes", [])
    ]
    if index_name in existing_indexes:
        logger.info("Vector Search index '%s' already exists.", index_name)
        return

    logger.info("Creating Vector Search index '%s' over '%s'...", index_name, source_table)
    client.create_delta_sync_index(
        endpoint_name=endpoint_name,
        index_name=index_name,
        source_table_name=source_table,
        pipeline_type="TRIGGERED",
        primary_key="chunk_id",
        embedding_dimension=3072,  # text-embedding-3-large output size
        embedding_vector_column="embedding_vector",
    )
    logger.info("Index '%s' created (TRIGGERED sync).", index_name)


def sync_index_if_needed(client: Optional[VectorSearchClient] = None) -> None:
    """
    Triggers a manual sync of the index from the Delta table's current
    state. Call this at the end of every ingestion run (see
    `notebooks/00_setup_and_deploy.py`) so newly-upserted chunks become
    searchable without waiting for a scheduled sync window.
    """
    client = client or get_vs_client()
    index_name = settings.vector_search_index_name

    index = client.get_index(
        endpoint_name=settings.vector_search_endpoint_name, index_name=index_name
    )
    logger.info("Triggering sync for index '%s'...", index_name)
    index.sync()
    logger.info("Sync triggered for '%s'. It may take a few minutes to complete.", index_name)


def setup_vector_search() -> None:
    """One-shot convenience: ensure endpoint + index both exist."""
    client = get_vs_client()
    create_endpoint_if_not_exists(client)
    create_index_if_not_exists(client)
