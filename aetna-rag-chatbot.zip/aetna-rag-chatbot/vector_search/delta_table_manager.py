"""
vector_search/delta_table_manager.py
======================================
STEP 5 of the architecture: Store Embeddings in Delta Table.

WHY A DELTA TABLE (not just an in-memory FAISS index)
--------------------------------------------------------
Delta Lake gives us ACID transactions, time travel, and Unity Catalog
governance on top of the raw chunk + embedding data:
- **Governance**: Unity Catalog lets you grant/revoke SELECT on this table
  independent of who can query the chatbot -- important when the
  underlying documents may later include member-specific attachments.
- **Time travel**: `DESCRIBE HISTORY` / `VERSION AS OF` let you roll back
  if a bad ingestion run corrupts embeddings, or audit "what did the bot
  know on March 1st" for a compliance question.
- **Change Data Feed**: Databricks Vector Search syncs from this table's
  CDC feed, so re-ingesting an updated EOC automatically propagates to
  the live index (see `vector_index_manager.py`).

SCHEMA
-------
    chunk_id           STRING   NOT NULL   -- deterministic, e.g. "Aetna_EOC_2026_pdf__p42__c1"
    document_name      STRING              -- original filename
    document_type      STRING              -- "Evidence of Coverage" | "SBC" | "Medicare Managed Care Manual"
    page_number         INT                -- 1-indexed page in the source PDF
    chunk_text         STRING              -- the raw chunk text (what gets shown as a citation snippet)
    embedding_vector    ARRAY<FLOAT>       -- 3072-dim vector from text-embedding-3-large
    created_timestamp   TIMESTAMP          -- when this row was written (for time-based debugging/audits)

`chunk_id` is the primary key (enforced logically via MERGE, since Delta
doesn't have traditional PK constraints) so re-running ingestion on an
unchanged PDF is a no-op, and re-running on an *updated* PDF section
correctly overwrites just the affected chunks.
"""

from typing import List

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    ArrayType,
    FloatType,
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from chunking.chunker import Chunk
from config.settings import settings
from utils.logging_utils import get_logger

logger = get_logger(__name__)


CHUNK_SCHEMA = StructType(
    [
        StructField("chunk_id", StringType(), nullable=False),
        StructField("document_name", StringType(), nullable=True),
        StructField("document_type", StringType(), nullable=True),
        StructField("page_number", IntegerType(), nullable=True),
        StructField("chunk_text", StringType(), nullable=True),
        StructField("embedding_vector", ArrayType(FloatType()), nullable=True),
        StructField("created_timestamp", TimestampType(), nullable=True),
    ]
)


def get_spark() -> SparkSession:
    """
    Returns the active Spark session. Inside a Databricks notebook/job,
    `spark` is already provided in the global namespace; this helper
    makes the module importable/testable outside that context too
    (tests mock this function rather than needing a live cluster).
    """
    return SparkSession.builder.getOrCreate()


def create_table_if_not_exists(spark: SparkSession = None) -> None:
    """
    Creates the Unity Catalog catalog/schema/table if they don't already
    exist. Idempotent -- safe to call at the start of every ingestion job.
    """
    spark = spark or get_spark()
    table_path = settings.full_delta_table_path

    spark.sql(f"CREATE CATALOG IF NOT EXISTS {settings.uc_catalog}")
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {settings.uc_catalog}.{settings.uc_schema}")

    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {table_path} (
            chunk_id           STRING NOT NULL,
            document_name      STRING,
            document_type      STRING,
            page_number        INT,
            chunk_text         STRING,
            embedding_vector   ARRAY<FLOAT>,
            created_timestamp  TIMESTAMP
        )
        USING DELTA
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        """
    )
    # Change Data Feed is required so Databricks Vector Search can do
    # incremental (rather than full-table-rescan) sync -- see
    # `vector_index_manager.py`.
    logger.info("Delta table ready at %s (CDC enabled).", table_path)


def _chunks_to_dataframe(chunks: List[Chunk], embeddings: List[List[float]], spark: SparkSession) -> DataFrame:
    """Zips chunk metadata with their embeddings into a Spark DataFrame."""
    if len(chunks) != len(embeddings):
        raise ValueError(
            f"chunks ({len(chunks)}) and embeddings ({len(embeddings)}) length mismatch."
        )

    rows = [
        (
            chunk.chunk_id,
            chunk.file_name,
            chunk.document_type,
            chunk.page_number,
            chunk.text,
            embedding,
        )
        for chunk, embedding in zip(chunks, embeddings)
    ]

    df = spark.createDataFrame(
        rows,
        schema=[
            "chunk_id",
            "document_name",
            "document_type",
            "page_number",
            "chunk_text",
            "embedding_vector",
        ],
    )
    return df.withColumn("created_timestamp", F.current_timestamp())


def upsert_chunks(
    chunks: List[Chunk],
    embeddings: List[List[float]],
    spark: SparkSession = None,
) -> int:
    """
    MERGE (upsert) chunks + their embeddings into the Delta table.

    WHY MERGE INSTEAD OF APPEND
    ------------------------------
    Insurance documents get updated (new plan year, corrected copay
    amounts). Using MERGE keyed on `chunk_id` means re-running ingestion
    on a revised EOC updates exactly the changed chunks in place, rather
    than accumulating duplicate/stale rows that would confuse retrieval
    (two near-identical chunks with different copay amounts is a
    dangerous state for a chatbot answering benefits questions).

    Returns
    -------
    int
        Number of chunks written (for logging / MLflow metrics).
    """
    spark = spark or get_spark()
    create_table_if_not_exists(spark)

    if not chunks:
        logger.warning("upsert_chunks called with an empty chunk list; nothing to do.")
        return 0

    new_data_df = _chunks_to_dataframe(chunks, embeddings, spark)
    new_data_df.createOrReplaceTempView("staged_chunks")

    table_path = settings.full_delta_table_path
    spark.sql(
        f"""
        MERGE INTO {table_path} AS target
        USING staged_chunks AS source
        ON target.chunk_id = source.chunk_id
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
        """
    )

    logger.info("Upserted %d chunks into %s.", len(chunks), table_path)
    return len(chunks)


def query_chunks_by_document_type(document_type: str, spark: SparkSession = None) -> DataFrame:
    """
    Convenience query used by debugging tools and the Streamlit sidebar's
    "Retrieved document count" panel -- e.g. to show how many chunks exist
    per source document type.
    """
    spark = spark or get_spark()
    table_path = settings.full_delta_table_path
    return spark.sql(
        f"SELECT * FROM {table_path} WHERE document_type = :doc_type",
        args={"doc_type": document_type},
    )
