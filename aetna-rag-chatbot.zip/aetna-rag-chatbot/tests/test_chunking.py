"""
tests/test_chunking.py
========================
Unit tests for `chunking/chunker.py`, covering chunk size/overlap behavior
and metadata propagation (the two things most likely to silently break
retrieval quality if changed carelessly).
"""

import pytest

from chunking.chunker import Chunk, _make_chunk_id, chunk_pages
from ingestion.pdf_loader import PageDocument


@pytest.fixture
def sample_page():
    # 2500 chars of filler text -- long enough to force multiple chunks
    # at the default chunk_size=1000.
    long_text = "Inpatient hospital coverage details. " * 70
    return PageDocument(
        file_name="Aetna_EOC_2026.pdf",
        document_type="Evidence of Coverage",
        page_number=12,
        text=long_text,
    )


class TestMakeChunkId:
    def test_deterministic(self):
        id1 = _make_chunk_id("Aetna_EOC_2026.pdf", 12, 0)
        id2 = _make_chunk_id("Aetna_EOC_2026.pdf", 12, 0)
        assert id1 == id2

    def test_unique_per_chunk_index(self):
        id1 = _make_chunk_id("Aetna_EOC_2026.pdf", 12, 0)
        id2 = _make_chunk_id("Aetna_EOC_2026.pdf", 12, 1)
        assert id1 != id2

    def test_sanitizes_filename(self):
        chunk_id = _make_chunk_id("Aetna EOC 2026.pdf", 1, 0)
        assert " " not in chunk_id
        assert chunk_id.count(".") == 0


class TestChunkPages:
    def test_produces_multiple_chunks_for_long_page(self, sample_page):
        chunks = chunk_pages([sample_page], chunk_size=1000, chunk_overlap=200)
        assert len(chunks) > 1
        assert all(isinstance(c, Chunk) for c in chunks)

    def test_chunk_size_respected_approximately(self, sample_page):
        chunks = chunk_pages([sample_page], chunk_size=1000, chunk_overlap=200)
        # RecursiveCharacterTextSplitter may go slightly under/at the
        # boundary when respecting sentence breaks -- allow small slack.
        for c in chunks:
            assert len(c.text) <= 1000 + 50

    def test_metadata_propagated(self, sample_page):
        chunks = chunk_pages([sample_page])
        for c in chunks:
            assert c.file_name == "Aetna_EOC_2026.pdf"
            assert c.document_type == "Evidence of Coverage"
            assert c.page_number == 12
            assert c.metadata["file_name"] == "Aetna_EOC_2026.pdf"
            assert c.metadata["document_type"] == "Evidence of Coverage"
            assert c.metadata["page_number"] == 12

    def test_empty_page_list_returns_empty(self):
        assert chunk_pages([]) == []

    def test_short_page_produces_single_chunk(self):
        short_page = PageDocument("SBC.pdf", "SBC", 1, "Short benefit summary text.")
        chunks = chunk_pages([short_page])
        assert len(chunks) == 1
        assert chunks[0].text == "Short benefit summary text."

    def test_chunk_ids_unique_across_whole_batch(self, sample_page):
        second_page = PageDocument(
            "Aetna_SBC_2026.pdf", "SBC", 1, "Coinsurance and copay details. " * 70
        )
        chunks = chunk_pages([sample_page, second_page])
        ids = [c.chunk_id for c in chunks]
        assert len(ids) == len(set(ids))
