"""
tests/test_ingestion.py
=========================
Unit tests for `ingestion/pdf_loader.py`. Uses mocking so tests run
without a real PDF file or Databricks/Azure connectivity.
"""

from unittest.mock import MagicMock, patch

import pytest

from ingestion.pdf_loader import PageDocument, infer_document_type, load_pdf, load_pdfs


class TestInferDocumentType:
    def test_infers_eoc(self):
        assert infer_document_type("Aetna_EOC_2026.pdf") == "Evidence of Coverage"

    def test_infers_sbc(self):
        assert infer_document_type("plan_SBC_summary.pdf") == "Summary of Benefits and Coverage"

    def test_infers_mmcm(self):
        assert infer_document_type("MMCM_chapter4.pdf") == "Medicare Managed Care Manual"

    def test_unknown_defaults_gracefully(self):
        assert infer_document_type("random_file.pdf") == "Unknown"

    def test_case_insensitive(self):
        assert infer_document_type("AETNA_eoc_FINAL.PDF") == "Evidence of Coverage"


class TestLoadPdf:
    @patch("ingestion.pdf_loader.fitz.open")
    def test_extracts_nonempty_pages(self, mock_fitz_open):
        mock_doc = MagicMock()
        mock_doc.page_count = 2

        page1 = MagicMock()
        page1.get_text.return_value = "Deductible information for plan year 2026."
        page2 = MagicMock()
        page2.get_text.return_value = ""  # blank page should be skipped

        mock_doc.load_page.side_effect = [page1, page2]
        mock_fitz_open.return_value = mock_doc

        result = load_pdf("Aetna_EOC_2026.pdf")

        assert len(result) == 1
        assert isinstance(result[0], PageDocument)
        assert result[0].page_number == 1
        assert result[0].document_type == "Evidence of Coverage"
        assert "Deductible" in result[0].text

    @patch("ingestion.pdf_loader.fitz.open")
    def test_corrupt_pdf_returns_empty_list(self, mock_fitz_open):
        mock_fitz_open.side_effect = Exception("corrupt file")

        result = load_pdf("broken.pdf")

        assert result == []

    @patch("ingestion.pdf_loader.fitz.open")
    def test_page_level_error_does_not_kill_whole_document(self, mock_fitz_open):
        mock_doc = MagicMock()
        mock_doc.page_count = 2

        good_page = MagicMock()
        good_page.get_text.return_value = "Good page text."

        mock_doc.load_page.side_effect = [
            Exception("bad page object"),
            good_page,
        ]
        mock_fitz_open.return_value = mock_doc

        result = load_pdf("mixed.pdf")

        assert len(result) == 1
        assert result[0].page_number == 2

    def test_explicit_document_type_overrides_inference(self):
        with patch("ingestion.pdf_loader.fitz.open") as mock_fitz_open:
            mock_doc = MagicMock()
            mock_doc.page_count = 1
            page = MagicMock()
            page.get_text.return_value = "Some text"
            mock_doc.load_page.return_value = page
            mock_fitz_open.return_value = mock_doc

            result = load_pdf("random_name.pdf", document_type="Custom Type")

            assert result[0].document_type == "Custom Type"


class TestLoadPdfs:
    @patch("ingestion.pdf_loader.load_pdf")
    def test_flattens_across_files(self, mock_load_pdf):
        mock_load_pdf.side_effect = [
            [PageDocument("a.pdf", "Evidence of Coverage", 1, "text a")],
            [PageDocument("b.pdf", "SBC", 1, "text b")],
        ]

        result = load_pdfs(["a.pdf", "b.pdf"])

        assert len(result) == 2
        assert mock_load_pdf.call_count == 2

    @patch("ingestion.pdf_loader.load_pdf")
    def test_one_bad_file_does_not_block_others(self, mock_load_pdf):
        mock_load_pdf.side_effect = [
            [],  # simulates a corrupt file returning empty
            [PageDocument("good.pdf", "SBC", 1, "text")],
        ]

        result = load_pdfs(["bad.pdf", "good.pdf"])

        assert len(result) == 1
