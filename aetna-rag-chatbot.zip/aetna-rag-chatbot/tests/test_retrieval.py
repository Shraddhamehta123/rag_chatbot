"""
tests/test_retrieval.py
=========================
Unit tests for `rag_pipeline/retrieval_service.py`. The Databricks Vector
Search client and the embedding call are both mocked so these tests run
without any live cloud resources.
"""

from unittest.mock import MagicMock, patch

import pytest

from rag_pipeline.retrieval_service import RetrievalService, RetrievedChunk


def _mock_similarity_search_result(rows):
    """rows: list of (chunk_id, text, doc_name, doc_type, page, score)"""
    return {"result": {"data_array": rows}}


@pytest.fixture
def mock_vs_client():
    client = MagicMock()
    index = MagicMock()
    client.get_index.return_value = index
    return client, index


class TestRetrieve:
    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_filters_below_threshold(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        index.similarity_search.return_value = _mock_similarity_search_result(
            [
                ("c1", "high relevance text", "EOC.pdf", "Evidence of Coverage", 1, 0.92),
                ("c2", "low relevance text", "EOC.pdf", "Evidence of Coverage", 2, 0.30),
            ]
        )

        service = RetrievalService(top_k=5, score_threshold=0.70, vs_client=client)
        results = service.retrieve("What is my deductible?")

        assert len(results) == 1
        assert results[0].chunk_id == "c1"

    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_respects_top_k(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        rows = [
            (f"c{i}", f"text {i}", "EOC.pdf", "Evidence of Coverage", i, 0.95 - i * 0.01)
            for i in range(10)
        ]
        index.similarity_search.return_value = _mock_similarity_search_result(rows)

        service = RetrievalService(top_k=3, score_threshold=0.0, vs_client=client)
        results = service.retrieve("query", top_k=3)

        assert len(results) == 3

    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_sorted_descending_by_score(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        index.similarity_search.return_value = _mock_similarity_search_result(
            [
                ("c1", "text", "EOC.pdf", "Evidence of Coverage", 1, 0.75),
                ("c2", "text", "EOC.pdf", "Evidence of Coverage", 2, 0.95),
                ("c3", "text", "EOC.pdf", "Evidence of Coverage", 3, 0.80),
            ]
        )

        service = RetrievalService(top_k=5, score_threshold=0.0, vs_client=client)
        results = service.retrieve("query")

        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_document_type_filter(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        index.similarity_search.return_value = _mock_similarity_search_result(
            [
                ("c1", "text", "EOC.pdf", "Evidence of Coverage", 1, 0.90),
                ("c2", "text", "SBC.pdf", "Summary of Benefits and Coverage", 1, 0.90),
            ]
        )

        service = RetrievalService(top_k=5, score_threshold=0.0, vs_client=client)
        results = service.retrieve(
            "query", document_type_filter="Summary of Benefits and Coverage"
        )

        assert len(results) == 1
        assert results[0].document_type == "Summary of Benefits and Coverage"

    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_hybrid_search_boosts_keyword_matches(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        index.similarity_search.return_value = _mock_similarity_search_result(
            [
                ("c1", "no relevant keywords here", "EOC.pdf", "Evidence of Coverage", 1, 0.71),
                (
                    "c2",
                    "prior authorization is required for outpatient surgery",
                    "EOC.pdf",
                    "Evidence of Coverage",
                    2,
                    0.71,
                ),
            ]
        )

        service = RetrievalService(
            top_k=5, score_threshold=0.70, enable_hybrid=True, vs_client=client
        )
        results = service.retrieve("prior authorization outpatient surgery")

        # c2 should be boosted above c1 due to keyword overlap.
        assert results[0].chunk_id == "c2"

    @patch("rag_pipeline.retrieval_service.generate_embeddings")
    def test_empty_results_returns_empty_list(self, mock_embed, mock_vs_client):
        client, index = mock_vs_client
        mock_embed.return_value = [[0.1] * 3072]
        index.similarity_search.return_value = _mock_similarity_search_result([])

        service = RetrievalService(vs_client=client)
        results = service.retrieve("obscure question")

        assert results == []
