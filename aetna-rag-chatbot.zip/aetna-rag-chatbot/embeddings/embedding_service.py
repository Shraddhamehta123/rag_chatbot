"""
embeddings/embedding_service.py
=================================
STEP 4 of the architecture: Generate Embeddings.

WHAT AN EMBEDDING IS (beginner note)
--------------------------------------
An embedding turns a chunk of text into a fixed-length vector of numbers
(3072 dimensions for `text-embedding-3-large`) such that semantically
similar text ends up as vectors that are close together in that
high-dimensional space. This lets us find "what's relevant to this
member's question" by comparing vectors with cosine similarity, instead
of relying on exact keyword matches (which would fail on "How much do I
pay for a hospital stay?" vs. a document that says "inpatient
coinsurance").

WHY BATCHING
-------------
The Azure OpenAI embeddings endpoint accepts multiple input strings per
call. Batching (default: 16 chunks/request) means embedding a 300-page
EOC document takes tens of API calls instead of thousands -- much faster
and much cheaper (fewer HTTP round trips), while staying safely under the
token-per-request limit for `text-embedding-3-large`.

WHY RETRY LOGIC
-----------------
Azure OpenAI enforces per-minute rate limits (TPM/RPM) and can return
transient 429/500 errors under load. During a full-corpus re-ingestion
run (thousands of chunks), hitting a rate limit is *expected*, not
exceptional -- so we use exponential backoff (via `tenacity`) rather than
letting the whole ingestion job crash on the first 429.
"""

from typing import List

from openai import AzureOpenAI
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from config.settings import settings
from utils.logging_utils import get_logger

logger = get_logger(__name__)

# A conservative batch size that stays well under the max-tokens-per-request
# limit even for long (near-1000-character) chunks.
DEFAULT_BATCH_SIZE = 16


def _get_client() -> AzureOpenAI:
    """
    Lazily construct the Azure OpenAI client so importing this module
    doesn't require valid credentials (important for unit tests that
    mock `generate_embeddings` without ever touching the network).
    """
    settings.validate()
    return AzureOpenAI(
        api_key=settings.azure_openai_key,
        api_version=settings.azure_openai_api_version,
        azure_endpoint=settings.azure_openai_endpoint,
    )


@retry(
    reraise=True,
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=2, max=30),
    retry=retry_if_exception_type(Exception),
)
def _embed_batch(client: AzureOpenAI, batch: List[str]) -> List[List[float]]:
    """
    Single Azure OpenAI embeddings call for one batch, wrapped in
    exponential backoff retry (2s, 4s, 8s, 16s, 30s-capped -- 5 attempts
    total). `reraise=True` means that if all 5 attempts fail, the
    original exception propagates so the caller/job scheduler sees a real
    error instead of a silently swallowed failure.
    """
    response = client.embeddings.create(
        model=settings.embedding_model,  # "text-embedding-3-large"
        input=batch,
    )
    # The API preserves input order in the response, so zipping back onto
    # the original chunk list downstream is safe.
    return [item.embedding for item in response.data]


def generate_embeddings(
    texts: List[str],
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> List[List[float]]:
    """
    Reusable embedding function used by both the offline ingestion
    pipeline (embedding thousands of chunks) and, if needed, ad-hoc
    query-time embedding (though `RetrievalService` typically delegates
    query embedding to Databricks Vector Search's managed embeddings
    endpoint -- see `vector_search/vector_index_manager.py`).

    Parameters
    ----------
    texts : List[str]
        Chunk texts to embed. Order is preserved in the output.
    batch_size : int
        Number of texts per Azure OpenAI API call.

    Returns
    -------
    List[List[float]]
        One embedding vector per input text, same order as `texts`.

    EXCEPTION HANDLING
    --------------------
    A batch that fails after all retries raises `RuntimeError` with
    enough context (batch index, size) to find and re-run just that slice
    rather than re-embedding the entire corpus.
    """
    if not texts:
        return []

    client = _get_client()
    all_embeddings: List[List[float]] = []
    num_batches = (len(texts) + batch_size - 1) // batch_size

    for batch_num in range(num_batches):
        start = batch_num * batch_size
        end = start + batch_size
        batch = texts[start:end]

        try:
            batch_embeddings = _embed_batch(client, batch)
        except Exception as exc:
            raise RuntimeError(
                f"Embedding failed for batch {batch_num + 1}/{num_batches} "
                f"(chunks {start}:{end}) after retries: {exc}"
            ) from exc

        all_embeddings.extend(batch_embeddings)
        logger.info(
            "Embedded batch %d/%d (%d texts).",
            batch_num + 1,
            num_batches,
            len(batch),
        )

    logger.info("Generated %d embeddings total.", len(all_embeddings))
    return all_embeddings
