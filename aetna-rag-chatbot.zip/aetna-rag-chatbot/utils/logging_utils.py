"""
utils/logging_utils.py
=======================
One shared logger factory so every module logs in the same format and can
be redirected (e.g. to a Delta table sink or Databricks job logs) from a
single place.

WHY STRUCTURED LOGGING MATTERS HERE
------------------------------------
This app touches insurance member questions. When something goes wrong in
production (a malformed PDF, a rate-limited embedding call, a bad
retrieval), you need to know: WHICH document, WHICH chunk, WHICH request,
WHEN. Plain `print()` statements can't be filtered/searched/alerted on --
a logger with levels and structured fields can.
"""

import logging
import sys
from typing import Optional


_CONFIGURED = False


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Return a module-level logger with a consistent format.

    Parameters
    ----------
    name : str
        Typically `__name__` of the calling module, so log lines show
        exactly which file emitted them.
    level : int
        Logging level (default INFO). Set to logging.DEBUG when
        `debug_mode` is enabled in the Streamlit sidebar.

    Returns
    -------
    logging.Logger
    """
    global _CONFIGURED

    if not _CONFIGURED:
        logging.basicConfig(
            level=level,
            format=(
                "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
            ),
            handlers=[logging.StreamHandler(sys.stdout)],
        )
        _CONFIGURED = True

    logger = logging.getLogger(name)
    logger.setLevel(level)
    return logger


def set_debug_mode(enabled: bool, logger: Optional[logging.Logger] = None) -> None:
    """
    Toggle DEBUG-level verbosity at runtime -- wired to the Streamlit
    sidebar's "Debug mode" checkbox so support engineers can get verbose
    retrieval/prompt logs without redeploying anything.
    """
    level = logging.DEBUG if enabled else logging.INFO
    logging.getLogger().setLevel(level)
    if logger is not None:
        logger.setLevel(level)
