"""
utils/feedback_logger.py
==========================
Enhancement 5: Feedback Logging.

Captures thumbs-up/down feedback from the Streamlit UI into a Delta
table, so product/compliance teams can review low-confidence or
negatively-rated answers -- especially important for a regulated
insurance use case where a wrong benefits answer has real member impact.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from pyspark.sql import SparkSession

from config.settings import settings
from utils.logging_utils import get_logger

logger = get_logger(__name__)

FEEDBACK_TABLE = f"{settings.uc_catalog}.{settings.uc_schema}.chat_feedback"


@dataclass
class FeedbackEvent:
    question: str
    answer: str
    rating: str  # "up" or "down"
    guardrail_flag: Optional[str] = None
    comment: Optional[str] = None


def ensure_feedback_table(spark: SparkSession) -> None:
    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {FEEDBACK_TABLE} (
            question         STRING,
            answer           STRING,
            rating           STRING,
            guardrail_flag   STRING,
            comment          STRING,
            created_timestamp TIMESTAMP
        )
        USING DELTA
        """
    )


def log_feedback(event: FeedbackEvent, spark: Optional[SparkSession] = None) -> None:
    """
    Writes one feedback row. Called from the Streamlit UI's
    thumbs-up/down buttons (see `frontend/app.py`).
    """
    spark = spark or SparkSession.builder.getOrCreate()
    ensure_feedback_table(spark)

    row = [
        (
            event.question,
            event.answer,
            event.rating,
            event.guardrail_flag,
            event.comment,
            datetime.now(timezone.utc),
        )
    ]
    df = spark.createDataFrame(
        row,
        schema=["question", "answer", "rating", "guardrail_flag", "comment", "created_timestamp"],
    )
    df.write.format("delta").mode("append").saveAsTable(FEEDBACK_TABLE)
    logger.info("Logged feedback rating='%s' for question='%s...'", event.rating, event.question[:60])
