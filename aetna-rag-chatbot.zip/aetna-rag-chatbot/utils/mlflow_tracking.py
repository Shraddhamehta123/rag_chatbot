"""
utils/mlflow_tracking.py
==========================
Observability: MLflow tracing, token usage, and response-time tracking.

WHY MLflow (beginner note)
-----------------------------
MLflow is an experiment-tracking tool. In a RAG chatbot we're not
training a model, but we still want a record of: what question came in,
what got retrieved, what the model answered, how long it took, and how
many tokens it burned -- so we can debug bad answers, tune chunk_size/
top_k, and track cost over time. MLflow's `start_run` groups all of that
into one inspectable record per request.
"""

import time
from contextlib import contextmanager
from typing import Dict, Optional

import mlflow

from config.settings import settings
from utils.logging_utils import get_logger

logger = get_logger(__name__)

_EXPERIMENT_SET = False


def _ensure_experiment() -> None:
    global _EXPERIMENT_SET
    if not _EXPERIMENT_SET:
        mlflow.set_experiment(settings.mlflow_experiment_name)
        _EXPERIMENT_SET = True


@contextmanager
def trace_rag_request(question: str):
    """
    Context manager wrapping one end-to-end chatbot turn. Usage:

        with trace_rag_request(question) as trace:
            ...
            trace.log_metric("num_chunks_retrieved", len(chunks))
            trace.log_param("top_k", 5)

    Automatically logs total wall-clock latency on exit, regardless of
    whether the block succeeded or raised.
    """
    _ensure_experiment()
    start = time.time()

    with mlflow.start_run(run_name="rag_request") as run:
        mlflow.log_param("question", question[:250])  # truncate for the UI

        class _TraceHandle:
            def log_metric(self, key: str, value: float) -> None:
                mlflow.log_metric(key, value)

            def log_param(self, key: str, value) -> None:
                mlflow.log_param(key, value)

            def log_text(self, text: str, artifact_file: str) -> None:
                mlflow.log_text(text, artifact_file)

        handle = _TraceHandle()
        try:
            yield handle
        finally:
            elapsed = time.time() - start
            mlflow.log_metric("latency_seconds", elapsed)
            logger.info("MLflow run %s logged (latency=%.2fs).", run.info.run_id, elapsed)


def log_token_usage(prompt_tokens: int, completion_tokens: int) -> None:
    """
    Call this right after an Azure OpenAI chat completion response
    (`response.usage`) inside an active `trace_rag_request` block, so
    cost/usage is captured per request rather than only in aggregate
    Azure billing (which can't be sliced by "which chatbot feature").
    """
    mlflow.log_metric("prompt_tokens", prompt_tokens)
    mlflow.log_metric("completion_tokens", completion_tokens)
    mlflow.log_metric("total_tokens", prompt_tokens + completion_tokens)
