
from utils.config import settings
try:
    import streamlit.runtime
    if streamlit.runtime.exists():
        import frontend.streamlit_ui
        frontend.streamlit_ui.run_app()
except Exception:
    pass  # Not in a Streamlit context

#databricks apps deploy aetna-rag-chatbot(1)
